class Disposable{
  void dispose(){

  }
}