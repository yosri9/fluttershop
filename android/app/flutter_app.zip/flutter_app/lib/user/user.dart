abstract class User{
String id;
String firstName;
String lastName;
String email;
String phone;
String gender;

User(this.id, this.firstName, this.lastName, this.email, this.phone,
    this.gender);


}