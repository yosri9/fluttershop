import 'dart:async';

import 'package:flutterstreamsproduct/contracts/disposable.dart';
import 'package:flutterstreamsproduct/models/note.dart';

class NoteBloc implements Disposable{
List<Note> notes;

final StreamController <List<Note>> _notesController =StreamController<List<Note>>();
Stream <List<Note>> get notesStream =>_notesController.stream;
StreamSink <List<Note>> get notesSink =>_notesController.sink ;


NoteBloc(){
 notes=[
   Note('note1'),
   Note('note2'),
   Note('note3'),
   Note('note4'),
 ];
 _notesController.add(notes);

}

@override
  void dispose() {
    _notesController.close();
  }

}