class Product{
  String id ;
  String title;
  int qty;

  Product(this.id, this.title, this.qty);


}