class Note{
  String content ;

  Note(this.content);





}