import 'package:flutter/material.dart';
import 'package:flutterstreamsproduct/blocs/note_bloc.dart';

class NotesList extends StatefulWidget {
  @override
  _NotesListState createState() => _NotesListState();
}

class _NotesListState extends State<NotesList> {
  NoteBloc noteBloc =NoteBloc();

  @override
  void dispose() {
  noteBloc.dispose();
  super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: noteBloc.notesStream,
      // ignore: missing_return
      builder:(BuildContext context,AsyncSnapshot snapshot){
        switch (snapshot.connectionState){
          case ConnectionState.none:
          case ConnectionState.waiting:
            print(snapshot.data);
            return Center(
              child: CircularProgressIndicator(),
              // ignore: missing_return
            );
            break;
          case ConnectionState.active:
          case ConnectionState.done:
            print(snapshot.data);
            if(snapshot.hasError){
              return Text('Error!');
            }else{
              return Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: <Widget>[
                    Flexible(
                      child: ListView.builder(
                          itemCount: snapshot.data.length,
                          itemBuilder: (context,position){
                           return ListTile(
                             title: Text(snapshot.data[position].content),
                           );
                          }),
                    ),
                    RaisedButton(
                        child: Text('ADD NEW'),
                        onPressed: (){

                        }
                    )
                  ],
                ),
              );
            }
            break;
        }
      } ,
    );
  }
}
